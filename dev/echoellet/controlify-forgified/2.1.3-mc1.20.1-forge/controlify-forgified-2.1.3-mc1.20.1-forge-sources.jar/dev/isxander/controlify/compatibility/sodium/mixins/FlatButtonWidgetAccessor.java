package dev.isxander.controlify.compatibility.sodium.mixins;

import me.jellysquid.mods.sodium.client.gui.widgets.FlatButtonWidget;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(value = FlatButtonWidget.class, remap = false)
public interface FlatButtonWidgetAccessor {
    @Invoker
    void invokeDoAction();
}

